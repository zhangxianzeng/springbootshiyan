package com.example.shiyanspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShiyanspringApplicationTests {

    @Test
    void contextLoads() {
    }

}
