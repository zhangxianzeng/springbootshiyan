package com.example.shiyanspring.pojo;

import java.util.List;

public class B {
    private String a_name;
    private String dizhi;
   // private List<A> a;
    public String getA_name() {
        return a_name;
    }

    public void setA_name(String a_name) {
        this.a_name = a_name;
    }

    public String getDizhi() {
        return dizhi;
    }

    public void setDizhi(String dizhi) {
        this.dizhi = dizhi;
    }


}
