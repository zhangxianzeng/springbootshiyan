package com.example.shiyanspring.Service;


import com.example.shiyanspring.pojo.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface UserService {
     List<User1> findName();
     List<User1> findName1(String name);
     int addAll(User1 user);
     int deleteAll(Integer id);
     int updateAll(User1 user);
      List<A> findAB();
     List<E> findAB1();
     Result zhuce(User user);
     List<User> chuxun(String username);
     Result denglu(User user, HttpServletRequest request, HttpServletResponse response);
     public int addUser(User user);
}
