package com.example.shiyanspring.contrller;


import com.example.shiyanspring.Service.UserService;
import com.example.shiyanspring.pojo.*;
import com.sun.tools.internal.xjc.reader.xmlschema.bindinfo.BIConversion;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.UUID;
//swagger访问地址ip+端口/swagger-ui.html
@RestController
//swagger框架整体
@Api(value = "/",description = "这是所有的接口文档")
@RequestMapping("/n")
public class UserContrller extends BaseContrller{
    @Autowired
    private UserService userService;
    @RequestMapping(value = "/name",method = RequestMethod.GET)
    @ApiOperation(value="这是返回字符串的get方法",httpMethod = "GET")
    public List<User1> findName(){
        return  userService.findName();
    }
    @RequestMapping(value = "/name1",method = RequestMethod.POST)
    @ApiOperation(value="已name为条件查询出所有符合的数据",httpMethod = "POST")
    public List<User1> findName1(String name){
        return  userService.findName1(name);
    }
    @RequestMapping(value = "/add",method =RequestMethod.POST)
    @ApiOperation(value="新增数据到数据库",httpMethod = "POST")
    public String findName2(User1 user){
       int a= userService.addAll(user);
        return  "新增了"+a+"数据";
    }
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    @ApiOperation(value="根据id删除数据",httpMethod = "POST")
    public String deleteName2(Integer id){
        int a= userService.deleteAll(id);
        return  "删除了"+a+"数据";
    }
    @RequestMapping(value = "/update",method =RequestMethod.POST)
    @ApiOperation(value="更改数据",httpMethod = "POST")
    public  String updateAll(User1 user){
        int a=userService.updateAll(user);
        if(a>=1){
            return "修改成功";
        }
        return "修改失败";
    }
    @RequestMapping(value = "/select",method = RequestMethod.GET)
    @ApiOperation(value="多表联查查询所有数据",httpMethod = "GET")
    public List<A> findAB(){

        return  userService.findAB();
    }
    @RequestMapping(value = "/select1",method = RequestMethod.GET)
    @ApiOperation(value="多表联查查询所有数据1",httpMethod = "GET")
    public List<E> findAB1(){

        return  userService.findAB1();
    }
    @RequestMapping(value = "zhuce",method = RequestMethod.POST)
    @ApiOperation(value="注册用户数据",httpMethod = "POST")
    public Result regist(User user){
        String pwd=	MD5Util.string2MD5(user.getPassword());
        user.setPassword(pwd);
        return userService.zhuce(user);
    }
    //根据当前登录的信息进行查询
    @RequestMapping(value = "chaxun",method = RequestMethod.GET)
    @ApiOperation(value="根据当前登录的信息进行查询登录后数据存入到session",httpMethod = "GET")
    public List<User> chaxun(){
      String  username=getUser().getUsername();
        return userService.chuxun(username);
    }
    @RequestMapping(value = "denglu",method = RequestMethod.POST)
    //这是swagger管理的接口
    @ApiOperation(value="这是登录接口",httpMethod = "POST")
    //登录接口在service层将登录信息存入到session，这样就可以利用session中到登录信息得到登录用户的数据
    public Result login(User user,HttpServletRequest request, HttpServletResponse response){
        String pwd=	MD5Util.string2MD5(user.getPassword());

        user.setPassword(pwd);

        return userService.denglu(user,request,response);
    }
    @RequestMapping("test")
    @ApiOperation(value="判断是否存在cookie",httpMethod = "GET")
    public String test(HttpServletRequest request, HttpServletResponse response){
        String cookieName="custom_global_session_id";
       // String encodeString="UTF-8";
        String cookieValue=CookieUtils.getCookieValue(request,cookieName);
        if(null==cookieValue || "".equals(cookieValue.trim())){
            System.out.println("无cookie，生产新的cookie");
         String   cookieValue1="ddddd";
            CookieUtils.setCookie(request,response,cookieName,cookieValue1);
        }

        return CookieUtils.getCookieValue(request,"custom_global_session_id");
    }

    //获取当前用户
    @RequestMapping(value = "/getUser",method = RequestMethod.GET)
    @ApiOperation(value="获取session中的当前用户的信息",httpMethod = "GET")
    public String getUser1() {
return getUser().getUsername();
    }

    //新增某个商品信息到登录账号中
    @RequestMapping(value = "/addUser",method = RequestMethod.POST)
    @ApiOperation(value="新增某个商品信息到登录账号中",httpMethod = "POST")
    public int addUser(User user){
        user.setUsername(getUser().getUsername());

        int a=userService.addUser(user);
        return a;
    }
    //退出登录删除session
    @RequestMapping(value = "/longout",method = RequestMethod.GET)
    @ApiOperation(value="退出登录",httpMethod = "GET")
    public String longout(HttpSession session){
        session.invalidate();    // 获取session信息，使session信息失效，直接返回登录界面，并连接跳转。
        return "退出成功请重新登录";

    }
    //登录时将登录信息存入到cookie，这样就可以得到cookie
    @RequestMapping(value = "/cookie",method = RequestMethod.GET)
    @ApiOperation(value = "得到cookie中存入到信息",httpMethod = "GET")
    public String getCookie(HttpServletRequest request,HttpServletResponse response){
        return CookieUtils.getCookieValue(request,"JT_TICKET");
    }

}
