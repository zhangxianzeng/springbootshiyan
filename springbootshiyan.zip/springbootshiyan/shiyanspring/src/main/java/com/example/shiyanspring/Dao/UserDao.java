package com.example.shiyanspring.Dao;


import com.example.shiyanspring.pojo.*;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@Mapper
public interface UserDao{
    List<User1> findAll1();

   List<User1> findAll2(@Param("name") String name);
   public int addAll(User1 user);
    public int deleteAll(@Param("id") Integer id);
    public int updateAll(User1 user);
    List<A> findAB();
    List<E> findAB1();
  public int zhuce(User user);
    List<User> chuxun(@Param("username") String username);
    List<User> denglu(@Param("username") String username,@Param("password") String password);
    //登录用户添加到表中用来规范某个账号到数据增加
    public int addUser(User user);
}
