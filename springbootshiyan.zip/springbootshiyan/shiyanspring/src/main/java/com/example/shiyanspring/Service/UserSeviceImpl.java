package com.example.shiyanspring.Service;


import com.example.shiyanspring.Dao.UserDao;
import com.example.shiyanspring.contrller.BaseContrller;
import com.example.shiyanspring.pojo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sun.nio.cs.US_ASCII;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Service
public class UserSeviceImpl extends BaseContrller implements UserService {
@Autowired
private UserDao userDao;
    @Override
    public List<User1> findName() {
        return userDao.findAll1();
    }

    @Override
    public List<User1> findName1(String name) {
        return userDao.findAll2(name);
    }

    @Override
    public int addAll(User1 user) {

        return userDao.addAll(user);
    }

    @Override
    public int deleteAll(Integer id) {
        return userDao.deleteAll(id);
    }

    @Override
    public int updateAll(User1 user) {
        return userDao.updateAll(user);
    }

    @Override
    public List<A> findAB() {
        return userDao.findAB();
    }

    @Override
    public List<E> findAB1() {
        List<E> result = userDao.findAB1();
        return result;
    }

    @Override
    public Result zhuce(User user) {
        Result result = new Result();
        result.setSuccess(false);
        result.setDetail(null);
        try {
            List<User> existUser = userDao.chuxun(user.getUsername());
            if(existUser.isEmpty()){
                userDao.zhuce(user);
                //System.out.println(user.getId());
                result.setMsg("注册成功");
                result.setSuccess(true);
                result.setDetail(user);


            }else{

                //如果用户名已存在
                result.setMsg("用户名已存在");
            }
        } catch (Exception e) {
            result.setMsg(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public List<User> chuxun(String username) {
        return userDao.chuxun(username);
    }

    @Override
    public Result denglu(User user, HttpServletRequest request, HttpServletResponse response) {
        Result result = new Result();
        result.setSuccess(false);
        result.setDetail(null);
        try {
            List<User> user1= userDao.denglu(user.getUsername(),user.getPassword());
            if(user1.isEmpty()){
                result.setMsg("用户名或密码错误");
            }else{
                User user2=new User();
                user2.setUsername(user.getUsername());
                user2.setPassword(user.getPassword());
                //将登录信息存储到session中，BaseContrller类就是存储session的工具类
                setUser(user2);
                result.setMsg("登录成功");
                result.setSuccess(true);
                //将登录信息存储到cookie中,CookieUtils就是存储cookie和查询cookie的工具类
                CookieUtils.setCookie(request, response, "JT_TICKET", user.getUsername());
                System.out.println(user.getUsername());
                result.setDetail(user);
            }
        } catch (Exception e) {
            result.setMsg(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    //新增
    @Override
    public int addUser(User user) {
        return userDao.addUser(user);
    }
}
